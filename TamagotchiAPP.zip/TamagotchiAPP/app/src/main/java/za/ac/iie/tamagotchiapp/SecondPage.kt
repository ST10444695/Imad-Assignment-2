package za.ac.iie.tamagotchiapp

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondPage : AppCompatActivity() {

  private var health = 100
  private var hunger = 0
  private var cleanliness = 100

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.second_activity)


    val feedBtn = findViewById<Button>(R.id.feedBtn)
    val cleanBtn = findViewById<Button>(R.id.cleanBtn)
    val playBtn = findViewById<Button>(R.id.playBtn)

    var imageResource = intent.getIntExtra("imageView", 0)
    var imageView = findViewById<ImageView>(R.id.imageView)

    imageView.setImageResource(imageResource)

    // Display initial status values
     health = 0
     hunger = 0
     cleanliness = 0
    updateStatusUI(health, hunger, cleanliness)

    feedBtn.setOnClickListener {
      health += 10
      hunger -= 20
      cleanliness -= 5

      health = health.coerceAtMost(100)
      hunger = hunger.coerceAtLeast(0)
      cleanliness = cleanliness.coerceAtLeast(0)

      updateStatusUI(health, hunger, cleanliness)

      imageView.setImageResource(R.drawable.feed)
    }
    cleanBtn.setOnClickListener {
      cleanliness += 20
      cleanliness = cleanliness.coerceAtMost(100)

      // Update UI
      updateStatusUI(health, hunger, cleanliness)

      imageView.setImageResource(R.drawable.clean)
    }

    playBtn.setOnClickListener {
      health -= 5
      hunger += 10

      health = health.coerceAtLeast(0)
      hunger = hunger.coerceAtLeast(0)

      // Update UI
      updateStatusUI(health, hunger, cleanliness)

      imageView.setImageResource(R.drawable.play)
    }
  }
  private fun updateStatusUI(health: Int, hunger: Int, cleanliness: Int) {
    val healthTextView = findViewById<TextView>(R.id.healthTextView)
    val hungerTextView = findViewById<TextView>(R.id.hungerTextView)
    val cleanlinessTextView = findViewById<TextView>(R.id.cleanlinessTextView)

    healthTextView.text = "Health: $health%"
    hungerTextView.text = "Hunger: $hunger%"
    cleanlinessTextView.text = "Cleanliness: $cleanliness%"
  }
}








